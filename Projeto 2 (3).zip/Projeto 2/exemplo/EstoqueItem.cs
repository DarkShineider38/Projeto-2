using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo

{
    public class EstoqueItem
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public int Quantidade { get; set; }

        private static string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public static List<EstoqueItem> BuscarPorNome(string nome)
        {
            var itens = new List<EstoqueItem>();

            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM estoque WHERE nome ILIKE @nome";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@nome", "%" + nome + "%");

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                itens.Add(new EstoqueItem
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Tipo = reader.GetString(2),
                    Quantidade = reader.GetInt32(3)
                });
            }

            return itens;
        }

        public static void Adicionar(EstoqueItem item)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();


            string selectSql = "SELECT id, quantidade FROM estoque WHERE LOWER(nome) = LOWER(@nome)";
            using var selectCommand = new NpgsqlCommand(selectSql, connection);
            selectCommand.Parameters.AddWithValue("@nome", item.Nome);

            using var reader = selectCommand.ExecuteReader();
            if (reader.Read())
            {

                int idExistente = reader.GetInt32(0);
                int quantidadeAtual = reader.GetInt32(1);
                int novaQuantidade = quantidadeAtual + item.Quantidade;

                reader.Close();

                string updateSql = "UPDATE estoque SET quantidade = @quantidade WHERE id = @id";
                using var updateCommand = new NpgsqlCommand(updateSql, connection);
                updateCommand.Parameters.AddWithValue("@quantidade", novaQuantidade);
                updateCommand.Parameters.AddWithValue("@id", idExistente);
                updateCommand.ExecuteNonQuery();
            }
            else
            {
                reader.Close();


                string insertSql = "INSERT INTO estoque (nome, tipo, quantidade) VALUES (@nome, @tipo, @quantidade)";
                using var insertCommand = new NpgsqlCommand(insertSql, connection);
                insertCommand.Parameters.AddWithValue("@nome", item.Nome);
                insertCommand.Parameters.AddWithValue("@tipo", item.Tipo);
                insertCommand.Parameters.AddWithValue("@quantidade", item.Quantidade);
                insertCommand.ExecuteNonQuery();
            }
        }

        public static bool AlterarQuantidade(int id, int novaQuantidade)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "UPDATE estoque SET quantidade = @quantidade WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@quantidade", novaQuantidade);
            command.Parameters.AddWithValue("@id", id);

            int linhasAfetadas = command.ExecuteNonQuery();
            return linhasAfetadas > 0;
        }


    }
}