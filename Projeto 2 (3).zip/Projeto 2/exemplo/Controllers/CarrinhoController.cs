using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace exemplo.Controllers
{
     [ApiController]
    [Route("[controller]")]
    public class CarrinhoController : ControllerBase
    {
        [HttpGet("listar")]
        public IActionResult Listar()
        {
            var itens = CarrinhoItem.Listar();
            if (itens.Count == 0)
                return NotFound("Carrinho vazio.");

            return Ok(itens);
        }

        [HttpPost("adicionar")]
        public IActionResult Adicionar([FromBody] CarrinhoItem item)
        {
            if (item == null || string.IsNullOrWhiteSpace(item.Nome) || item.Quantidade <= 0)
                return BadRequest("Dados inválidos.");

            CarrinhoItem.Adicionar(item);
            return Ok("Item adicionado ao carrinho.");
        }

        [HttpDelete("remover/{id}")]
        public IActionResult Remover(int id)
        {
            bool removido = CarrinhoItem.Remover(id);
            if (removido)
                return Ok($"Item com ID {id} removido.");
            else
                return NotFound($"Item com ID {id} não encontrado.");
        }

        [HttpDelete("esvaziar")]
        public IActionResult Esvaziar()
        {
            CarrinhoItem.Esvaziar();
            return Ok("Carrinho esvaziado.");
        }
    }
}