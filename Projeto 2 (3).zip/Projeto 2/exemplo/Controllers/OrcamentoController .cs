using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrcamentoController : ControllerBase
    {
        [HttpPost("adicionar")]
        public IActionResult Adicionar([FromBody] Orcamento orc)
        {
            if (string.IsNullOrWhiteSpace(orc.Chassi) || orc.HorasServico < 0 || orc.CustoMateriais < 0 || orc.CustoPecas < 0)
                return BadRequest("Dados inválidos.");

            Orcamento.Adicionar(orc);
            return Ok("Orçamento adicionado com sucesso.");
        }

        [HttpGet("todos")]
        public IActionResult BuscarTodos()
        {
            var lista = Orcamento.BuscarTodos();
            return Ok(lista);
        }

        [HttpGet("por-chassi/{chassi}")]
        public IActionResult BuscarPorChassi(string chassi)
        {
            var lista = Orcamento.BuscarPorChassi(chassi);
            if (lista.Count == 0)
                return NotFound("Nenhum orçamento encontrado para este chassi.");

            return Ok(lista);
        }
    }
}