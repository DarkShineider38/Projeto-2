using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EstoqueController : ControllerBase
    {

        [HttpGet("buscar-por-nome")]
        public IActionResult BuscarPorNome(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome))
                return BadRequest("Nome não informado");

            var itens = EstoqueItem.BuscarPorNome(nome);
            if (itens.Count == 0)
                return NotFound("Nenhum item encontrado");

            return Ok(itens);
        }


        [HttpPost("adicionar")]
        public IActionResult Adicionar([FromBody] EstoqueItem item)
        {
            if (item == null || string.IsNullOrWhiteSpace(item.Nome) || string.IsNullOrWhiteSpace(item.Tipo) || item.Quantidade < 0)
            {
                return BadRequest("Dados inválidos");
            }

            EstoqueItem.Adicionar(item);
            return Ok("Item adicionado ou atualizado com sucesso!");
        }

        [HttpPut("alterar-quantidade")]
        public IActionResult AlterarQuantidade([FromBody] AlterarEstoque request)
        {
            if (request == null || request.Id <= 0 || request.Quantidade < 0)
                return BadRequest("Dados inválidos.");

            bool atualizado = EstoqueItem.AlterarQuantidade(request.Id, request.Quantidade);

            if (atualizado)
                return Ok($"Quantidade do item com ID {request.Id} foi atualizada para {request.Quantidade}.");
            else
                return NotFound($"Item com ID {request.Id} não foi encontrado.");
        }
    }
}

