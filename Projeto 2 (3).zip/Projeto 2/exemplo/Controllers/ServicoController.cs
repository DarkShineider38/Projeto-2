using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("servico")]
    public class ServicoController : ControllerBase
    {
        [HttpPost("adicionar")]
        public IActionResult Adicionar([FromBody] Servico servico)
        {
            if (servico.ClienteId <= 0 || servico.TipoServicoId < 1 || servico.TipoServicoId > 2 || servico.Status < 1 || servico.Status > 3)
            {
                return BadRequest("Dados inválidos. Verifique os IDs e status.");
            }

            Servico.Adicionar(servico);
            return Ok("Serviço cadastrado com sucesso.");
        }

        [HttpGet("status/{status}")]
        public IActionResult BuscarPorStatus(int status)
        {
            if (status < 1 || status > 3)
                return BadRequest("Status inválido (1=Começando, 2=Quase pronto, 3=Finalizado)");

            var servicos = Servico.BuscarPorStatus(status);
            if (servicos.Count == 0)
                return NotFound("Nenhum serviço encontrado para esse status.");

            return Ok(servicos);
        }

        [HttpGet("cliente/{clienteId}")]
        public IActionResult BuscarPorCliente(int clienteId)
        {
            var servicos = Servico.BuscarPorClienteId(clienteId);
            if (servicos.Count == 0)
                return NotFound("Nenhum serviço encontrado para este cliente.");

            return
             Ok(servicos);
        }

        [HttpPut("atualizar-status/{id}")]
        public IActionResult AtualizarStatus(int id, [FromBody] int novoStatus)
        {
            if (novoStatus < 1 || novoStatus > 3)
                return BadRequest("Status inválido (1=Começando, 2=Quase pronto, 3=Finalizado)");

            bool atualizado = Servico.AtualizarStatus(id, novoStatus);
            if (!atualizado)
                return NotFound("Serviço não encontrado.");

            return Ok("Status atualizado com sucesso.");
        }

        [HttpDelete("deletar/{id}")]
        public IActionResult Deletar(int id)
        {
            bool deletado = Servico.DeletarPorId(id);

            if (deletado)
                return Ok($"Serviço com ID {id} foi deletado com sucesso.");
            else
                return NotFound($"Serviço com ID {id} não encontrado.");
        }
    }
}