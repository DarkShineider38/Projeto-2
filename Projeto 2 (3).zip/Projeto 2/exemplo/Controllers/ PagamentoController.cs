using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PagamentoController : ControllerBase
    {
        [HttpPost("adicionar")]
        public IActionResult Adicionar([FromBody] Pagamento pagamento)
        {
            if (pagamento.Valor <= 0 || pagamento.ClienteId <= 0)
                return BadRequest("Dados inválidos");

            Pagamento.Adicionar(pagamento);
            return Ok("Pagamento registrado com sucesso.");
        }

        [HttpGet("listar")]
        public IActionResult Listar()
        {
            var lista = Pagamento.ListarTodos();
            return Ok(lista);
        }

        [HttpPut("atualizar-status/{clienteId}")]
        public IActionResult AtualizarStatus(int clienteId, [FromBody] int novoStatus)
        {
            if (novoStatus != 1 && novoStatus != 2)
                return BadRequest("Status inválido. Use 1 para 'Pagou' e 2 para 'Pagando'.");

            Pagamento.AtualizarStatus(clienteId, novoStatus);
            return Ok($"Status de pagamento do cliente {clienteId} atualizado para {novoStatus}.");
        }
    }
}