using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Collections.Generic;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClienteController : ControllerBase
    {
        private readonly ILogger<ClienteController> _logger;
        private readonly string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public ClienteController(ILogger<ClienteController> logger)
        {
            _logger = logger;
        }

        [HttpGet("buscar-por/{id}")]
        public IActionResult GetPorId(int id)
        {
            var cliente = new Cliente();
            cliente.CarregarCliente(id);
            if (cliente.Id == 0)
                return NotFound("Cliente não encontrado");

            return Ok(cliente);
        }


        [HttpGet("todos-clientes")]
        public IActionResult GetTodosClientes()
        {
            var clientes = Cliente.CarregarTodosClientes();
            return Ok(clientes);
        }


        [HttpDelete("deletar-cliente/{id}")]
        public IActionResult Delete(int id)
        {
            var cliente = new Cliente();
            cliente.ExcluirCliente(id);
            return NoContent();
        }


        [HttpPost("adicionar-cliente")]
        public IActionResult Post([FromBody] Cliente dados)
        {
            if (dados == null)
                return BadRequest("Objeto inválido");


            if (string.IsNullOrWhiteSpace(dados.Seguradora))
                dados.Seguradora = null;

            dados.Salvardados();
            return Ok("Cliente cadastrado com sucesso");
        }


        [HttpPut("alterar-dados")]
        public IActionResult Put([FromBody] Cliente dados)
        {
            if (dados == null)
                return BadRequest("Objeto inválido");

            if (string.IsNullOrWhiteSpace(dados.Seguradora))
                dados.Seguradora = null;

            dados.Alterardados();
            return Ok("Cliente alterado com sucesso");
        }


        [HttpGet("buscar-por-nome")]
        public IActionResult BuscarPorNome(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome))
                return BadRequest("Nome não informado");

            var clientes = new List<Cliente>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string sql = "SELECT * FROM cliente WHERE nome ILIKE @nome";
                using (var command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@nome", "%" + nome + "%");
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            clientes.Add(new Cliente
                            {
                                Id = reader.GetInt32(0),
                                Nome = reader.GetString(1),
                                Endereco = reader.GetString(2),
                                Telefone = reader.GetString(3),
                                Documento = reader.GetString(4),
                                Seguradora = reader.IsDBNull(5) ? null : reader.GetString(5)
                            });
                        }
                    }
                }
            }

            return Ok(clientes);
        }


        [HttpGet("buscar-por-documento")]
        public IActionResult BuscarPorDocumento(string documento)
        {
            if (string.IsNullOrWhiteSpace(documento))
                return BadRequest("Documento não informado");

            var cliente = Cliente.CarregarPorDocumento(documento);

            if (cliente == null)
                return NotFound("Cliente não encontrado");

            return Ok(cliente);
        }
    }
}
