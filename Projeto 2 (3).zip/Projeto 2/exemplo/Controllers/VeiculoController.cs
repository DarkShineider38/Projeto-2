using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VeiculoController : ControllerBase
    {
        [HttpPost("Cadastrar-veiculo")]
        public IActionResult Cadastrar([FromBody] Veiculo v)
        {
            try
            {
                v.CadastrarVeiculo();
                return Ok("Veículo cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao cadastrar: " + ex.Message);
            }
        }

        [HttpPut("Alterar-dados-do-veiculo")]
        public IActionResult Alterar([FromBody] Veiculo v)
        {
            try
            {
                v.AlterarVeiculo();
                return Ok("Veículo alterado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao alterar: " + ex.Message);
            }
        }


        [HttpGet("Buscar-por{id}")]
        public IActionResult Get(int id)
        {
            var veiculo = new Veiculo();
            veiculo.CarregarVeiculo(id);
            return Ok(veiculo);
        }


        [HttpGet("Buscar-por-marca/modelo")]
        public IActionResult BuscarPorNome([FromQuery] string nome)
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            List<Veiculo> veiculos = new List<Veiculo>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT v.id, v.marca, v.modelo, v.ano, v.placa, v.chassi, c.nome, c.telefone
            FROM veiculo v
            JOIN cliente c ON v.id_cliente = c.id
            WHERE LOWER(v.modelo) LIKE LOWER(@nome) OR LOWER(v.marca) LIKE LOWER(@nome);
        ";

                using (var command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("nome", $"%{nome}%");

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            veiculos.Add(new Veiculo
                            {
                                Id = reader.GetInt32(0),
                                Marca = reader.GetString(1),
                                Modelo = reader.GetString(2),
                                Ano = reader.GetInt32(3),
                                Placa = reader.GetString(4),
                                Chassi = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Proprietario = reader.GetString(6),
                                Telefone = reader.GetString(7)
                            });
                        }
                    }
                }
            }

            return Ok(veiculos);
        }


        [HttpGet("Buscar-por-placa-ou-chassi")]
        public IActionResult BuscarPorPlacaOuChassi([FromQuery] string placa = "", [FromQuery] string chassi = "")
        {
            if (string.IsNullOrWhiteSpace(placa) && string.IsNullOrWhiteSpace(chassi))
            {
                return BadRequest("Informe ao menos a placa ou o chassi para a busca.");
            }

            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            List<Veiculo> veiculos = new List<Veiculo>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT v.id, v.marca, v.modelo, v.ano, v.placa, v.chassi, c.nome, c.telefone
            FROM veiculo v
            JOIN cliente c ON v.id_cliente = c.id
            WHERE 1=1
        ";

                if (!string.IsNullOrWhiteSpace(placa))
                {
                    sql += " AND LOWER(v.placa) LIKE LOWER(@placa)";
                }

                if (!string.IsNullOrWhiteSpace(chassi))
                {
                    sql += " AND LOWER(v.chassi) LIKE LOWER(@chassi)";
                }

                using (var command = new NpgsqlCommand(sql, connection))
                {
                    if (!string.IsNullOrWhiteSpace(placa))
                        command.Parameters.AddWithValue("@placa", $"%{placa}%");

                    if (!string.IsNullOrWhiteSpace(chassi))
                        command.Parameters.AddWithValue("@chassi", $"%{chassi}%");

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            veiculos.Add(new Veiculo
                            {
                                Id = reader.GetInt32(0),
                                Marca = reader.GetString(1),
                                Modelo = reader.GetString(2),
                                Ano = reader.GetInt32(3),
                                Placa = reader.GetString(4),
                                Chassi = reader.GetString(5),
                                Proprietario = reader.GetString(6),
                                Telefone = reader.GetString(7)
                            });
                        }
                    }
                }
            }

            if (veiculos.Count == 0)
                return NotFound("Nenhum veículo encontrado com os dados informados.");

            return Ok(veiculos);
        }


        [HttpGet("todos-veiculos")]
        public IActionResult ObterTodos()
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            List<Veiculo> veiculos = new List<Veiculo>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT v.id, v.marca, v.modelo, v.ano, v.placa, v.chassi, c.nome, c.telefone
            FROM veiculo v
            JOIN cliente c ON v.id_cliente = c.id;
        ";

                using (var command = new NpgsqlCommand(sql, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        veiculos.Add(new Veiculo
                        {
                            Id = reader.GetInt32(0),
                            Marca = reader.GetString(1),
                            Modelo = reader.GetString(2),
                            Ano = reader.GetInt32(3),
                            Placa = reader.GetString(4),
                            Chassi = reader.GetString(5),
                            Proprietario = reader.GetString(6),
                            Telefone = reader.GetString(7)
                        });
                    }
                }
            }

            return Ok(veiculos);
        }
        [HttpDelete("deletar-por{id}")]
        public IActionResult ExcluirPorId(int id)
        {
            try
            {
                var v = new Veiculo();
                v.ExcluirVeiculoId(id);
                return Ok("Veículo excluído com sucesso!");
            }
            catch
            {
                return BadRequest("Erro ao excluir.");
            }
        }

        [HttpDelete("excluir-por-placa")]
        public IActionResult ExcluirPorPlaca([FromQuery] string placa)
        {
            if (string.IsNullOrWhiteSpace(placa))
            {
                return BadRequest("Você deve informar a placa do veículo.");
            }

            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            int linhasAfetadas = 0;

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                var comando = new NpgsqlCommand("DELETE FROM veiculo WHERE placa = @placa", connection);
                comando.Parameters.AddWithValue("@placa", placa);
                linhasAfetadas = comando.ExecuteNonQuery();
            }

            if (linhasAfetadas > 0)
            {
                return Ok("Veículo excluído com sucesso.");
            }
            else
            {
                return NotFound("Nenhum veículo encontrado com a placa informada.");
            }
        }

    }
}