using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
    public class CarrinhoItem
    {
         public int Id { get; set; }
        public string Nome { get; set; }
        public int Quantidade { get; set; }

        private static string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public static List<CarrinhoItem> Listar()
        {
            var itens = new List<CarrinhoItem>();

            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM carrinho";
            using var command = new NpgsqlCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                itens.Add(new CarrinhoItem
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Quantidade = reader.GetInt32(2)
                });
            }

            return itens;
        }

        public static void Adicionar(CarrinhoItem item)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "INSERT INTO carrinho (nome, quantidade) VALUES (@nome, @quantidade)";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@nome", item.Nome);
            command.Parameters.AddWithValue("@quantidade", item.Quantidade);
            command.ExecuteNonQuery();
        }

        public static bool Remover(int id)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "DELETE FROM carrinho WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", id);

            int linhasAfetadas = command.ExecuteNonQuery();
            return linhasAfetadas > 0;
        }

        public static void Esvaziar()
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "DELETE FROM carrinho";
            using var command = new NpgsqlCommand(sql, connection);
            command.ExecuteNonQuery();
        }
    }
}