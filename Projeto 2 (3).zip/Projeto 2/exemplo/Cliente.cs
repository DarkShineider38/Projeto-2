using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
  public class Cliente
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public string Documento { get; set; }
        public string? Seguradora { get; set; }

        private object GetValueOrDBNull(string? valor)
        {
            if (string.IsNullOrWhiteSpace(valor))
                return DBNull.Value;
            return valor!;
        }

        public void CarregarCliente(int id)
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM cliente WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", id);

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                Id = reader.GetInt32(0);
                Nome = reader.GetString(1);
                Endereco = reader.GetString(2);
                Telefone = reader.GetString(3);
                Documento = reader.GetString(4);
                Seguradora = reader.IsDBNull(5) ? null : reader.GetString(5);
            }
        }

        public void ExcluirCliente(int id)
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "DELETE FROM cliente WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }

        public void Salvardados()
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "INSERT INTO cliente (id, nome, endereco, telefone, documento, seguradora) VALUES (@id, @nome, @endereco, @telefone, @documento, @seguradora)";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", Id);
            command.Parameters.AddWithValue("@nome", Nome);
            command.Parameters.AddWithValue("@endereco", Endereco);
            command.Parameters.AddWithValue("@telefone", Telefone);
            command.Parameters.AddWithValue("@documento", Documento);
            command.Parameters.AddWithValue("@seguradora", GetValueOrDBNull(Seguradora));
            command.ExecuteNonQuery();
        }

        public void Alterardados()
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "UPDATE cliente SET nome=@nome, endereco=@endereco, telefone=@telefone, documento=@documento, seguradora=@seguradora WHERE id=@id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@nome", Nome);
            command.Parameters.AddWithValue("@endereco", Endereco);
            command.Parameters.AddWithValue("@telefone", Telefone);
            command.Parameters.AddWithValue("@documento", Documento);
            command.Parameters.AddWithValue("@seguradora", GetValueOrDBNull(Seguradora));
            command.Parameters.AddWithValue("@id", Id);
            command.ExecuteNonQuery();
        }

        public static List<Cliente> CarregarTodosClientes()
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            var clientes = new List<Cliente>();

            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM cliente";
            using var command = new NpgsqlCommand(sql, connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                var cliente = new Cliente
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Endereco = reader.GetString(2),
                    Telefone = reader.GetString(3),
                    Documento = reader.GetString(4),
                    Seguradora = reader.IsDBNull(5) ? null : reader.GetString(5)
                };
                clientes.Add(cliente);
            }

            return clientes;
        }

        public static Cliente? CarregarPorDocumento(string documento)
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            Cliente? cliente = null;

            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM cliente WHERE documento = @documento";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@documento", documento);

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                cliente = new Cliente
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Endereco = reader.GetString(2),
                    Telefone = reader.GetString(3),
                    Documento = reader.GetString(4),
                    Seguradora = reader.IsDBNull(5) ? null : reader.GetString(5)
                };
            }

            return cliente;
        }
    }
}
  
