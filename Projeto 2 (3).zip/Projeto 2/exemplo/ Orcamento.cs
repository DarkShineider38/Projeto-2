using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;


namespace exemplo
{
    public class  Orcamento
    {
        public int Id { get; set; }
        public string Chassi { get; set; }
        public int HorasServico { get; set; }
        public decimal CustoMateriais { get; set; }
        public decimal CustoPecas { get; set; }
        public decimal ValorTotal => (HorasServico * 100) + CustoMateriais + CustoPecas; 

        private static string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public static void Adicionar(Orcamento orc)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"INSERT INTO orcamento (chassi, horas_servico, custo_materiais, custo_pecas, valor_total) 
                           VALUES (@chassi, @horas, @materiais, @pecas, @total)";
            using var cmd = new NpgsqlCommand(sql, connection);
            cmd.Parameters.AddWithValue("@chassi", orc.Chassi);
            cmd.Parameters.AddWithValue("@horas", orc.HorasServico);
            cmd.Parameters.AddWithValue("@materiais", orc.CustoMateriais);
            cmd.Parameters.AddWithValue("@pecas", orc.CustoPecas);
            cmd.Parameters.AddWithValue("@total", orc.ValorTotal);
            cmd.ExecuteNonQuery();
        }

        public static List<Orcamento> BuscarTodos()
        {
            var lista = new List<Orcamento>();
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT id, chassi, horas_servico, custo_materiais, custo_pecas FROM orcamento";
            using var cmd = new NpgsqlCommand(sql, connection);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lista.Add(new Orcamento
                {
                    Id = reader.GetInt32(0),
                    Chassi = reader.GetString(1),
                    HorasServico = reader.GetInt32(2),
                    CustoMateriais = reader.GetDecimal(3),
                    CustoPecas = reader.GetDecimal(4)
                });
            }

            return lista;
        }

        public static List<Orcamento> BuscarPorChassi(string chassi)
        {
            var lista = new List<Orcamento>();
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT id, chassi, horas_servico, custo_materiais, custo_pecas FROM orcamento WHERE chassi = @chassi";
            using var cmd = new NpgsqlCommand(sql, connection);
            cmd.Parameters.AddWithValue("@chassi", chassi);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lista.Add(new Orcamento
                {
                    Id = reader.GetInt32(0),
                    Chassi = reader.GetString(1),
                    HorasServico = reader.GetInt32(2),
                    CustoMateriais = reader.GetDecimal(3),
                    CustoPecas = reader.GetDecimal(4)
                });
            }

            return lista;
        }
    }
}
    
