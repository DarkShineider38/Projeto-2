using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
    public class Pagamento
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public decimal Valor { get; set; }
        public int FormaPagamento { get; set; }
        public int TipoPagamento { get; set; }
        public int Status { get; set; }

        private static string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public static void Adicionar(Pagamento pagamento)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"INSERT INTO pagamento (cliente_id, valor, forma_pagamento, tipo_pagamento, status)
                           VALUES (@cliente_id, @valor, @forma_pagamento, @tipo_pagamento, @status)";

            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@cliente_id", pagamento.ClienteId);
            command.Parameters.AddWithValue("@valor", pagamento.Valor);
            command.Parameters.AddWithValue("@forma_pagamento", pagamento.FormaPagamento);
            command.Parameters.AddWithValue("@tipo_pagamento", pagamento.TipoPagamento);
            command.Parameters.AddWithValue("@status", pagamento.Status);

            command.ExecuteNonQuery();
        }

        public static List<Pagamento> ListarTodos()
        {
            var lista = new List<Pagamento>();
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "SELECT * FROM pagamento";
            using var command = new NpgsqlCommand(sql, connection);
            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                lista.Add(new Pagamento
                {
                    Id = reader.GetInt32(0),
                    ClienteId = reader.GetInt32(1),
                    Valor = reader.GetDecimal(2),
                    FormaPagamento = reader.GetInt32(3),
                    TipoPagamento = reader.GetInt32(4),
                    Status = reader.GetInt32(5)
                });
            }

            return lista;
        }

        public static void AtualizarStatus(int clienteId, int novoStatus)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"UPDATE pagamento SET status = @status 
                   WHERE cliente_id = @cliente_id";

            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@status", novoStatus);
            command.Parameters.AddWithValue("@cliente_id", clienteId);

            command.ExecuteNonQuery();
        }
    }
}

