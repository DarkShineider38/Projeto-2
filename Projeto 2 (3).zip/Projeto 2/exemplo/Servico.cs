using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
    public class Servico
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public int TipoServicoId { get; set; }
        public int Status { get; set; }
        public DateTime DataServico { get; set; }

        private static string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

        public static void Adicionar(Servico servico)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"INSERT INTO servico (cliente_id, tipo_servico_id, status) 
                           VALUES (@cliente_id, @tipo_servico_id, @status)";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@cliente_id", servico.ClienteId);
            command.Parameters.AddWithValue("@tipo_servico_id", servico.TipoServicoId);
            command.Parameters.AddWithValue("@status", servico.Status);
            command.ExecuteNonQuery();
        }

        public static List<Servico> BuscarPorStatus(int status)
        {
            var lista = new List<Servico>();
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"SELECT id, cliente_id, tipo_servico_id, status, data_servico 
                           FROM servico WHERE status = @status";

            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@status", status);

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Servico
                {
                    Id = reader.GetInt32(0),
                    ClienteId = reader.GetInt32(1),
                    TipoServicoId = reader.GetInt32(2),
                    Status = reader.GetInt32(3),
                    DataServico = reader.GetDateTime(4)
                });
            }

            return lista;
        }

        public static List<Servico> BuscarPorClienteId(int clienteId)
        {
            var lista = new List<Servico>();
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = @"SELECT id, cliente_id, tipo_servico_id, status, data_servico 
                           FROM servico WHERE cliente_id = @cliente_id";

            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@cliente_id", clienteId);

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Servico
                {
                    Id = reader.GetInt32(0),
                    ClienteId = reader.GetInt32(1),
                    TipoServicoId = reader.GetInt32(2),
                    Status = reader.GetInt32(3),
                    DataServico = reader.GetDateTime(4)
                });
            }

            return lista;
        }
        public static bool AtualizarStatus(int id, int novoStatus)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "UPDATE servico SET status = @status WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@status", novoStatus);
            command.Parameters.AddWithValue("@id", id);

            int linhasAfetadas = command.ExecuteNonQuery();
            return linhasAfetadas > 0;
        }

        public static bool DeletarPorId(int id)
        {
            using var connection = new NpgsqlConnection(connectionString);
            connection.Open();

            string sql = "DELETE FROM servico WHERE id = @id";
            using var command = new NpgsqlCommand(sql, connection);
            command.Parameters.AddWithValue("@id", id);

            int linhasAfetadas = command.ExecuteNonQuery();
            return linhasAfetadas > 0;
        }
    }
}

