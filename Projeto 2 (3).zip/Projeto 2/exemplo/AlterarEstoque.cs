using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
    public class AlterarEstoque
    {
        public int Id { get; set; }
        public int Quantidade { get; set; }
    }
}